package com.pet.javalip;
import java.lang.*;
public class MyClass {
    public static void main(String args[])
    {
        int a=5;
        int m,n;
        int s=5;
        int b=2;
        int c=1;
        int x=10;
        int y=2;
        int p=2;
        m=++a*5;
        p*=x/y;
        s/=5;
        n=b++ - c*2;
        System.out.println(m);
        System.out.println(p);
        System.out.println(s);
        System.out.println(n);
    }
}
