package com.pet.lib2;

public class MyClass {
}
