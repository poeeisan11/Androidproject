package com.pet.avajlib;

public class MyClass {
}
